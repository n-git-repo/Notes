package example.domain.web.webdriver;

public interface Page {
    void verify(Browser browser);
}
