create table document (
  document_id varchar(255) not null,
  created_at timestamp,
  updated_at timestamp,
  primary key (document_id)
);
