$(document).ready(function() {
    $('#date').datepicker({ dateFormat: 'dd/mm/yy' });
});
