$(document).ready(function() {
    $('#currentForms').dataTable({
        'bJQueryUI': true,
        "aaSorting": [[ 2, "desc" ]]
    });
});
