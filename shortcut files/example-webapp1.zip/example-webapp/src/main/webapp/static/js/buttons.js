$(document).ready(function() {
    $('input:submit, input:reset').button();
});
