package example.spring;

public interface ApplicationStatus {
    boolean ready();
}
