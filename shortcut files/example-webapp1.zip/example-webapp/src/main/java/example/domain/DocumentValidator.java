package example.domain;

public interface DocumentValidator {
    void validate(Document document);
}
