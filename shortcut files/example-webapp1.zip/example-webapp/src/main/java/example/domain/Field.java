package example.domain;

public enum Field {
    one, two, date
}
