This is both a template project for my J2EE applications and an idea bucket for how to create, configure and code
web applications. It represents some of the ideas that I have either encountered or am experimenting with at any
given moment.